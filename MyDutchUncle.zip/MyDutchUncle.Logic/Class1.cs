﻿using System;

namespace MyDutchUncle.Logic
{
    public class Class1
    {
    }
}
