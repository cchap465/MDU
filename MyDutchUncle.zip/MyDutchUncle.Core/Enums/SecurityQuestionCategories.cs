﻿using System;

namespace MyDutchUncle.Core.Enums
{
    public enum SecurityQuestionCategories
    {
        MothersMaidenName,
        FathersMothersName,
        CityMarriedIn,
        CityBornIn,
        OldestCousin,
        YoungestCousin
    }
}
