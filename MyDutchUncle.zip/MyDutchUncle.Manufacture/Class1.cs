﻿using System;

namespace MyDutchUncle.Manufacture
{
    public class Class1
    {
    }
}
